/**
*
*/
import java.util.*;
import java.io.*;
/**

* @author Jerry Heuring
* Test class for the Project 0
*/
public class Project0Helper {
  static private final int MAX_ADDRESSES = 10000;

  protected ArrayList<Integer> zipList;
  long startTime, endTime;
  int outOfOrder, missingZip;
  /**

  * Constructor -- does initial setup and initialization.
  */
  public Project0Helper() {

    zipList = new ArrayList<Integer> (MAX_ADDRESSES);
    startTime = 0;
    endTime = 0;
    outOfOrder = 0;
    missingZip = 0;
  }
  /**
  * This checks the initial group of addresses and starts the
  * timer for the run.
  * @param mailingList The list of addresses in their original order.
  */

  public void checkStartingOrder(MailAddressInterface mailingList[]) {
    for (int i = 0; i < mailingList.length; i++) {
      if (mailingList[i] != null) {
        zipList.add(mailingList[i].getZipCode());
      }
    }
    startTime = System.currentTimeMillis();

  }
  /**
  * This method will check for some error conditions in the data
  * such as addresses not in ascending order and mismatches in terms
  * of zip codes.
  * It also outputs the time for the sort.
  *
  * @param mailingList The list of addresses in sorted order.
  */

  public void checkFinalOrder(MailAddressInterface mailingList[]) {
    int finalListSize = mailingList.length;
    endTime = System.currentTimeMillis();
    for (int i = 0; i < mailingList.length; i++) {

      if (mailingList[i] == null) {
        finalListSize = i;
        break;

      }
    }
    if (zipList.size() != finalListSize) {
      System.out.println("Final list size does not match initial list size!");
      System.out.println("Initial List Size = " + zipList.size() );
      System.out.println("Final List Size = " + finalListSize);

    } else {
      System.out.println("Initial and Final list sizes match.");
    }
    for (int i=1; i < finalListSize; i++) {
      if (mailingList[i-1].getZipCode() > mailingList[i].getZipCode()) {
        System.out.println("Zip Code Out of Order");
        System.out.println("Address " + (i-1));
        System.out.println(mailingList[i-1]);
        System.out.println("Address " + (i));
        System.out.println(mailingList[i]);
        outOfOrder++;
      }

    }
    zipList.sort(null);
    for (int i = 0; i < finalListSize; i++) {

      if (mailingList[i].getZipCode() != zipList.get(i).intValue()) {
        System.out.println("Expecting to see zip code"+zipList.get(i).intValue());
        System.out.println("Found: ");
        System.out.println(mailingList[i]);
        missingZip++;

      }
    }
    System.out.println("Time Taken = "+(endTime - startTime)+" msec");
  }

  public void dumpZipList(MailAddressInterface myList[], int i) {
    //dump zip list
    System.out.print("i=" + i + " ");
    for(int k = 0; k < myList.length; k++){
      System.out.print(myList[k].getZipCode() + " ");
    }
    System.out.println();
  }
  public void radixSortZip(MailAddressInterface myList[]) {

    for(int i = 1; i <= 5; i++){ //for each digit in ZIP

      //dumpZipList(myList, i);

      //create 10 buckets
      ArrayList<MailAddressInterface>[] bucket = new ArrayList[10];
      for(int j=0; j < 10; j++){
        bucket[j] = new ArrayList<MailAddressInterface>();
      }

      //sort by i-th digit

      for(int k = 0; k < myList.length; k++){
        final int digit = myList[k].getZipCodeDigit(i);
        //System.out.println("["+ i + "]ZIP " + myList[k].getZipCode() + " to bin " + digit);
        bucket[digit].add(myList[k]);
      }

      Arrays.fill(myList, null);

      //copy elements
      int k = 0;
      for(int j=0; j < 10; j++){
        for(MailAddressInterface ma: bucket[j]){
          myList[k++] = ma;
        }
      }
    }

    //dumpZipList(myList, 6);
  }

  /**

  * Main program reads in a test file and uses it. The class
  * ConcreteMailClass implements the MailAddressInterface. The
  * ConcreteMailClass is NOT supplied -- you need to make your
  * own implementation of the ConcreteMailAddress class and then
  * you can substitute it in here if you wish.
  * @param args command line arguments -- not used.
  */
  public static void main(String[] args) {

    MailAddressInterface myList[] = new ConcreteMailAddress[MAX_ADDRESSES];

    Project0Helper helper = new Project0Helper();

    Scanner myscanner;
    Scanner myinput = new Scanner(System.in);

    try {
      //ask user for input filename
      System.out.print("Enter filename: ");
      String input_filename = myinput.nextLine();
      System.out.println("Filename is: " + input_filename);
      myinput.close();

      myscanner = new Scanner(new File(input_filename));

      int i = 0;
      try {

        //read until EOF
        while(myscanner.hasNextLine()){

          //System.out.println("i = " + String.valueOf(i));

          //check if our array is full
          if (i >= MAX_ADDRESSES){
            System.out.println("Error: Reached max addresses limit");
            break;
          }

          //parse the address from input
          String name     = myscanner.nextLine();
          String address1 = myscanner.nextLine();
          String address2="", city="", state="";

          //records may have 1,2 or 3 address lines
          Stack<String> lines = new Stack<String>();
          String line = myscanner.nextLine();


          while(true){
            lines.add(line);
            line = myscanner.nextLine();

            //until we reach the ZIP code line
            if(line.length() == 5 && line.matches("\\d{5}")){
              break;
            }
          }
          int zip = Integer.parseInt(line);

          state = lines.pop();  //state is before zip
          city = lines.pop();   //city is before state
          while(!lines.empty()){
            address2 += lines.pop();  //append rest as address 2
          }

          //create the address class
          myList[i] = new ConcreteMailAddress(name, address1, address2, city, state, zip);
          //System.out.println(myList[i]);
          i++;
        }
      } catch(NoSuchElementException e) {
        // end of input?
        System.out.println("No such element " + e);
      }
      myscanner.close();

      //resize to number of addresses inserted
      myList = Arrays.copyOf(myList, i-1);

      //sort the array, using radix sort
      helper.radixSortZip(myList);
      helper.checkStartingOrder(myList);
      helper.checkFinalOrder(myList);

      // save list to file
      FileWriter myWriter = new FileWriter("output.txt");
      for(int k = 0; k < myList.length; k++){
        myWriter.write(myList[k].toString());
      }
      myWriter.close();

    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }

    System.exit(0);
  }
}
