public class ConcreteMailAddress implements MailAddressInterface {
  private String name;
  private String address1, address2;
  private String city;
  private String state;
  private int zip;
  private int zipStr;
  private int[] zipcode;

  /**
  * Class to represent a mail address
  * @param name Personal name
  * @param address1 First address
  * @param address2 Second address
  * @param city     City
  * @param state    State
  * @param zip      ZIP code ( up to 5 digits)
  */
  public ConcreteMailAddress(String name, String address1, String address2, String city, String state, int zip){
    this.name = name;
    this.address1 = address1;
    this.address2 = address2;
    this.city = city;
    this.state = state;
    this.zip = zip;

    zipcode = new int[5];

    for(int i=0; i < 5; i++){
      zipcode[i] = 0;
    }
    String s = String.valueOf(zip);
    for(int i=0; i < s.length(); i++){
      zipcode[i] = s.charAt(s.length() - 1 - i) - '0';
    }
  }

  /**
  * Get the name line for this address.
  * @return the name line for this address (Mr. John Doe)
  */
  public String getName(){
    return name;
  }

  /**
  * Get the first address line for this address.
  * @return First line of the street address for this address
  */
  public String getAddressLine1(){
    return address1;
  }

  /**
  * Get the second address line for this address (may be null or the
  * empty string if there is none).
  * @return Second line of the street address (if any) for this address
  */
  public String getAddressLine2(){
    return address2;
  }

  /**
  * Get the city for this address.
  *
  * @return The name of the city for this address.
  */
  public String getCity(){
    return city;
  }

  /**
  * Get the name of the state or the state abbreviation for this address.
  * @return The name of the state or the abbreviation of the state for this address.
  */
  public String getState(){
    return state;
  }

  /**
  * Get the zip code for this address.
  * @return The 5 digit zip code for this address.
  */
  public int getZipCode(){
    return zip;
  }

  /**
  * Get the n't digit of the zip code for this address. Digit 1 is the units digit and
  * zip codes MUST be only 5 digits for this project. If my zip code is 98765 then
  * digit 1 = 5
  * digit 2 = 6
  * digit 3 = 7
  * digit 4 = 8
  * digit 5 = 9
  *
  * @param digit which digit of the zip code to return. Digit 1 is the units digit.
  * @return The n'th digit of the zip code.
  */
  public int getZipCodeDigit(int digit){
    return zipcode[digit-1];
  }

  public String toString(){
      String rv = name      + "\n"
                + address1 + "\n";

      if(address2.length() > 0){
        rv += address2 + "\n";
      }

      rv += city  + "\n"
         + state  + "\n"
         + zip + "\n";

      return rv;
  }
}
