''' 
	template.py

	A general template for starting Python programs using pylab.
'''


# from pylab import *

import matplotlib.pyplot as plt
import numpy as np
from scipy import optimize


# insert code here...
g = 9.8
v = 4.8
h=1.2
desired_range = 1

def DistanceFromTarget(theta):
	R = v*np.cos(theta)/g*(v*np.sin(theta) + np.sqrt(v**2*np.sin (theta)**2 + 2*g*h)) - desired_range
	return R

theta = np.arange(0, 1.6, 0.04)
plt.plot(theta, DistanceFromTarget(theta), 'b-')
answer1 = optimize.brentq(DistanceFromTarget, 1.2, 1.4)
plt.title("desired_range=1 h=1.2 v=4.8 g=9.8")
plt.xlabel("launch angle (radians)")
plt.ylabel("How much you miss by(m)")
plt.show()
print(answer1)
