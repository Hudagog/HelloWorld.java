import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# postion = [0, -2, -11, -15, -24, -32, -40, -50, -52, -62, -65]
# turn = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
turn = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape((-1, 1))
postion = np.array([0, -2, -11, -15, -24, -32, -40, -50, -52, -62, -65])

new_model = LinearRegression().fit(turn, postion.reshape((-1, 1)))
b1 = new_model.coef_
b0 = new_model.intercept_

line_pos = turn * b1 + b0
plt.scatter(turn, postion, color='r')
plt.plot(turn, line_pos)
plt.xlabel("turn number")
plt.ylabel("degree")
plt.title('6 Soultion')
plt.show()