import matplotlib.pyplot as plt
import numpy as np

g = 9.81    # We are on Earth.
dt = 0.1    # 1/10 second time step
N = 100     # I'd like to see 100 points in the answer array
vi = 50.0   # initial velocity
xi = 25.0   # initial position
w = 0.2

# first, set up variables and almost-empty arrays to hold our answers:
t = 0
x = xi
v = vi
time = np.array([0])       # initial value of time is zero!
height = np.array([xi])    # initial height is xi
velocity = np.array([vi])  # initial velocity is vi
# Note that 't', 'x' and 'v' are the current time, position and velocity, but 
# 'time', 'height' and 'velocity' are arrays that will contain all the positions
# and velocities at all values of 'time'.

# Now let's use Euler's method to find the position and velocity.
for j in range(N):
    # here are the calculations:
    t = t + dt
    x = x + v * dt	# x = x + dx = x + v*dt
    v = v - w * x * dt	# v = v + dv = v + a*dt
    # And here we put those calculations in the arrays to plot later:
    time = np.append(time,t)
    height = np.append(height,x)
    velocity = np.append(velocity,v)

# Now that the calculations are done, plot the position:
plt.plot(time, height, 'ro')
plt.xlabel("Time (s)")
plt.ylabel("Height (m)")

# just for comparison, I'll also plot the known solution!
plt.plot(time, xi + vi*time - 0.5*g*time**2, 'b-')
plt.show()
