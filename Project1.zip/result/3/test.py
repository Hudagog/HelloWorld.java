''' 
	template.py

	A general template for starting Python programs using pylab.
'''


# from pylab import *

import matplotlib.pyplot as plt
import numpy as np


# insert code here...
g = 9.8
def y(t, y0, v0):
	y = y0 + v0*t - 9.8*(t**2)/2
	return y
def t(v0, theta):
	t = 2*v0*np.sin(theta)/g
	return t
def d(v0, theta, t):
	d = v0*np.cos(theta)*t
	return d
def R(v0, theta):
	R = (v0**2)*np.sin(2*theta)/g
	return R
theta = np.arange(0, np.pi/2, 0.04)
plt.plot(theta, R(4.8, theta), 'b-')
t0 = t(4.8, theta)
plt.scatter(theta, d(4.8, theta, t0), 20 , 'r')
plt.title("R range")
plt.xlabel("theta(radians)")
plt.ylabel("R distance(m)")
plt.show()