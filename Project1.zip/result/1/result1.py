''' 
	template.py

	A general template for starting Python programs using pylab.
'''


# from pylab import *

import matplotlib.pyplot as plt
import numpy as np


# insert code here...
t = np.linspace(0, 10*np.pi, 1000)
z = np.exp(-t/10) * np.sin(t)
plt.plot(t,z,'b-')
plt.title("Cool! It works!")
plt.xlabel("time")
plt.ylabel("displacement")
plt.show()