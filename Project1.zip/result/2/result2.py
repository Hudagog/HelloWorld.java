''' 
	template.py

	A general template for starting Python programs using pylab.
'''


# from pylab import *

import matplotlib.pyplot as plt
import numpy as np


# insert code here...
g = 9.8
def v(t):
	v = -9.8*t
	return v
def y(t):
	y = -9.8*(t**2)/2
	return y
t = np.linspace(5, 1)
plt.plot(t,v(t),'g-')
plt.plot(t,y(t),'r-')
plt.title("Solution to Exercise 2")
plt.xlabel("time(s)")
plt.ylabel("Position(m) and velocity(m/s)")
plt.show()