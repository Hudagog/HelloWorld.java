class Point {
  public int row;
  public int col;

  public Point(int row, int col){
    this.row = row;
    this.col = col;
  }

  // correctly overrides Object.equals(Object)
  public boolean equals(Object obj) {
    if (obj != null && getClass() == obj.getClass()) {
        Point q = (Point)obj;
        return row == q.row && col == q.col;
    }
    return false;
  }
}
