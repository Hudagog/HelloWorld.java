import java.util.*;
import java.io.*;

class Project2Main {
  private static final int BOARD_SIZE = 8;
  private static boolean[][] visited = new boolean[BOARD_SIZE][BOARD_SIZE];

  //coordinate offsets for a-h moves
  private final static int [] rows = new int[]{-2,-2,-1, 1, 2, 2,  1,-1};
  private final static int [] cols = new int[]{-1, 1, 2, 2, 1,-1, -2,-2};

  private static Point enterPoint(Scanner myinput, String msg){

    boolean invalidRange = true;

    int row = 0, col = 0;

    while(invalidRange){
      System.out.println(msg);

      String line = myinput.nextLine();

      //split line into two tokents
      String[] str = line.split("\\s+");

      row = Integer.parseInt(str[0]);
      col = Integer.parseInt(str[1]);

      if((row < 0) || (row >= BOARD_SIZE)){
        System.out.println("The row must be between 0 and 7. Try again.");
        continue;
      }

      if((col < 0) || (col >= BOARD_SIZE)){
        System.out.println("The column must be between 0 and 7. Try again");
        continue;
      }

      break;
    }

    return new Point(row, col);
  }

  private static PointQueue generateMoves(Point start){

    PointQueue moves = new PointQueue();

    //generate the moves from a to h
    for(int i=0; i < 8; i++){
      final int r = start.row + rows[i];
      final int c = start.col + cols[i];

      if( (r >= 0) && (r < BOARD_SIZE) &&
          (c >= 0) && (c < BOARD_SIZE) &&
          (!visited[r][c])){
        moves.push(new Point(r, c));
      }
    }
    return moves;
  }

  private static PointQueue rFindPath(Point startP, Point finalP){

    //don't come back at this square
    visited[startP.row][startP.col] = true;

    if(startP.equals(finalP)){

      PointQueue rv = new PointQueue();
      rv.push(startP);

      //Since point is from a valid path, going to final, we allow revisit
      visited[startP.row][startP.col] = false;

      return rv;

    }else{

      //generate all positions from current
      PointQueue moves    = generateMoves(startP);
      PointQueue shortest = new PointQueue(); //shortest path

      //test all positions from current point recursively
      while(!moves.isEmpty()){
        //take first position from queue
        Point p = moves.pop();

        //try to fina a path from it
        PointQueue subpath = rFindPath(p, finalP);

        //if the there is a path
        if(!subpath.isEmpty()){

          //Since point is from a valid path, going to final, we allow revisit
          visited[p.row][p.col] = false;

          //add current position to it
          subpath.push(startP);

          //Don't return, but find the sub-path with smallest size ?
          if(shortest.isEmpty() || (shortest.size() > subpath.size())){
            shortest = subpath;
          }
        }
      }

      return shortest;
    }
  }

  private static void clear_visited(){
    for(int i=0; i < BOARD_SIZE; i++){
      for(int j=0; i < BOARD_SIZE; i++){
        visited[i][j] = false;
      }
    }
  }

  public static void main(String[] args) {

    clear_visited();

    Scanner myinput = new Scanner(System.in);

    Point startPoint = enterPoint(myinput, "Input the starting row and column separated by a space:");
    Point finalPoint = enterPoint(myinput, "Input the final row and column separated by a space:");
    myinput.close();

    //the path knight took
    PointQueue path = rFindPath(startPoint, finalPoint);

    if(!path.isEmpty()){
      path.reverse();
      System.out.println("Found path");
      while(!path.isEmpty()){
        Point p = path.pop();
        System.out.printf("%d %d\n", p.row, p.col);
      }
    }
  }
}
