import java.util.*;

class PointQueue{
  private ArrayList<Point> values;

  public PointQueue(){
    values = new ArrayList<Point>();
  }

  public boolean isEmpty(){
    return values.isEmpty();
  }

  public void push(Point p){
    values.add(p);
  }

  public Point pop(){
    Point p = values.get(0);
    values.remove(0);
    return p;
  }

  public int size(){
    return values.size();
  }

  //pop and push each element to reverse the queue order
  public void reverse(){
    Collections.reverse(values);
  }
}
