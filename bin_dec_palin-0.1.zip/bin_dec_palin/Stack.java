import java.util.ArrayList;

class Stack{
  private ArrayList<Character> values;

  public Stack(){
    values = new ArrayList<Character>();
  }

  public boolean isEmpty(){
    return values.isEmpty();
  }

  public void push(Character v){
    values.add(v);
  }

  public Character pop(){

    int last = values.size() - 1;

    //get last elemtn
    Character v = values.get(last);
    values.remove(last);

    return v;
  }
}
