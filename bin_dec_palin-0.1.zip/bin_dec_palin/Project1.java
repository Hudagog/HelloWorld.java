/**
* @author
* Class for the Project 1
*/

import java.util.*;
import java.io.*;

class Project1{

  /*
  * Convert decimal to string
  */
  private static String dec2str(int value){
    String decValue = String.format("%d", value);
    return decValue;
  }

  /*
  * Convert decimal to binary string
  */
  private static String dec2bin(int value){
    String binValue = "";
    while(value > 0){
      int digit = value % 2;
      binValue += Integer.toString(digit);

      value /= 2;
    }
    return binValue;
  }

  /* Check if a string is palindrome, using a stack
  */
  private static boolean isPalindrome(String val){
    Stack stk = new Stack();
    String reverse = "";

    //push the string to stack
    for(int i=0; i < val.length(); i++){
      stk.push(val.charAt(i));
    }

    //pop the string to reverse it
    while(!stk.isEmpty()){
      reverse += stk.pop();
    }

    //if string and reverse are equal, its a palindrome
    return val.equals(reverse);
  }

  /**
  * Main program
  * @param args command line arguments -- not used.
  */
  public static void main(String[] args) {

    int from=0, to=0;
    boolean invalidRange = true;
    Scanner myinput = new Scanner(System.in);

    while(invalidRange){
      //read the user input line
      System.out.print("Input Range > ");
      String line = myinput.nextLine();

      //split line into two tokents
      String[] str = line.split("\\s+");

      from = Integer.parseInt(str[0]);
      to = Integer.parseInt(str[1]);

      //do some checks
      if(from >= to){
        System.err.println("Error: First number is larger than second number. Try again.");
        continue;
      }

      //do some checks
      if((from <= 0) || (to <= 0)){
        System.err.println("Error: Invalid value entered. All values must be greater than zero. Try again.");
        continue;
      }
      break;
    }
    myinput.close();

    System.out.println("Palindromes:");
    System.out.printf("\t%-10s\t\t%-10s\n", "Base10", "Binary");
    //check for palindromes
    for(int i=from; i <= to; i++){

      String decValue = dec2str(i);
      String binValue = dec2bin(i);

      if(isPalindrome(decValue) && isPalindrome(binValue)){
        System.out.printf("\t%-10s\t\t%-10s\n", decValue, binValue);
      }
    }

    System.exit(0);
  }
}
